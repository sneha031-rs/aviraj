import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import confetti from "canvas-confetti";
import FloatingHearts from "@/components/FloatingHearts";
import Sparkles from "@/components/Sparkles";
import BirthdayCake from "@/components/BirthdayCake";
import GiftCard from "@/components/GiftCard";

const gifts = [
  {
    emoji: "🎁",
    title: "Gift of Happiness",
    message: "May every moment of your life be filled with pure joy and endless laughter. You deserve all the happiness in the world! 🌟",
    color: "bg-rose-light",
  },
  {
    emoji: "🌹",
    title: "Endless Love",
    message: "You are loved more than words can express. Your beautiful soul lights up everyone's life around you! 💕",
    color: "bg-card",
  },
  {
    emoji: "⭐",
    title: "Dream Big",
    message: "May all your dreams come true this year. The universe has so many wonderful things planned for you! ✨",
    color: "bg-muted",
  },
  {
    emoji: "🎀",
    title: "Beautiful You",
    message: "You're the most beautiful person inside and out. Never stop being the amazing person you are! 🦋",
    color: "bg-rose-light",
  },
  {
    emoji: "🍰",
    title: "Sweet Moments",
    message: "Life is sweeter because you're in it. Here's to more sweet moments and beautiful memories together! 🍫",
    color: "bg-card",
  },
  {
    emoji: "🌈",
    title: "Colorful Life",
    message: "May your life be as colorful and vibrant as a rainbow after rain. You bring color to everyone's life! 🎨",
    color: "bg-muted",
  },
];

const Index = () => {
  const hasConfetti = useRef(false);

  useEffect(() => {
    if (!hasConfetti.current) {
      hasConfetti.current = true;
      setTimeout(() => {
        confetti({
          particleCount: 150,
          spread: 100,
          origin: { y: 0.6 },
          colors: ["#e84393", "#fd79a8", "#fab1a0", "#ffeaa7", "#dfe6e9", "#a29bfe"],
        });
      }, 1000);
    }
  }, []);

  const triggerConfetti = () => {
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.7 },
      colors: ["#e84393", "#fd79a8", "#fab1a0", "#ffeaa7", "#a29bfe"],
    });
  };

  return (
    <div className="min-h-screen bg-background overflow-x-hidden relative">
      <FloatingHearts />
      <Sparkles />

      {/* Hero Section */}
      <section className="min-h-screen flex flex-col items-center justify-center relative px-4">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-center z-10"
        >
          <motion.p
            className="text-lg md:text-xl text-muted-foreground mb-4 tracking-widest uppercase"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            ✨ Today is a very special day ✨
          </motion.p>

          <motion.h1
            className="text-6xl md:text-8xl lg:text-9xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent animate-gradient mb-6"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 100, delay: 0.5 }}
          >
            Happy Birthday, Trisha!
          </motion.h1>

          <motion.p
            className="text-2xl md:text-3xl text-foreground/80 mb-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            🎀 To the most amazing girl, Trisha 🎀
          </motion.p>

          <motion.p
            className="text-lg md:text-xl text-muted-foreground mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
          >
            With love from Aviraj 💕
          </motion.p>

          <BirthdayCake />

          <motion.button
            onClick={triggerConfetti}
            className="mt-8 px-8 py-4 bg-primary text-primary-foreground rounded-full text-lg font-semibold shadow-lg animate-glow hover:scale-105 transition-transform"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5 }}
          >
            🎉 Click for Surprise! 🎉
          </motion.button>
        </motion.div>

        <motion.div
          className="absolute bottom-8 text-muted-foreground"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <p className="text-sm">Scroll down for your gifts 💝</p>
          <p className="text-center text-2xl">↓</p>
        </motion.div>
      </section>

      {/* Message Section */}
      <section className="py-20 px-4 relative z-10">
        <motion.div
          className="max-w-2xl mx-auto text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <h2 className="text-5xl md:text-6xl text-primary mb-8">A Special Message 💌</h2>
          <div className="bg-card rounded-3xl p-8 md:p-12 shadow-xl border border-border">
            <p className="text-lg md:text-xl leading-relaxed text-foreground/80 font-[var(--font-body)]">
              On this beautiful day, I just want you to know how grateful I am to have you in my life.
              Your smile brightens my darkest days, your laughter is my favorite melody,
              and your friendship is the greatest gift I've ever received.
            </p>
            <br />
            <p className="text-lg md:text-xl leading-relaxed text-foreground/80 font-[var(--font-body)]">
              May this year bring you everything your heart desires — love, happiness,
              success, and all the beautiful things you truly deserve. 🌸
            </p>
            <p className="mt-6 text-2xl">💖 With all my love, Aviraj 💖</p>
          </div>
        </motion.div>
      </section>

      {/* Gifts Section */}
      <section className="py-20 px-4 relative z-10">
        <motion.h2
          className="text-5xl md:text-6xl text-center text-primary mb-12"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          Your Birthday Gifts 🎁
        </motion.h2>
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {gifts.map((gift, i) => (
            <GiftCard key={i} {...gift} delay={i * 0.15} />
          ))}
        </div>
      </section>

      {/* Wishes Section */}
      <section className="py-20 px-4 relative z-10">
        <motion.div
          className="max-w-3xl mx-auto text-center"
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
        >
          <div className="text-7xl mb-6">🎈🎈🎈</div>
          <h2 className="text-5xl md:text-6xl text-primary mb-6">Birthday Wishes</h2>
          <div className="space-y-4">
            {[
              "May your birthday be as sweet as you are 🍭",
              "Wishing you a year full of adventures 🌍",
              "May every wish you make come true ⭐",
              "Here's to another year of being fabulous 💅",
              "May your life be filled with love & laughter 😄",
            ].map((wish, i) => (
              <motion.p
                key={i}
                className="text-lg md:text-xl text-foreground/70 py-3 px-6 bg-card rounded-full inline-block mx-2 shadow-sm"
                initial={{ opacity: 0, x: i % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
              >
                {wish}
              </motion.p>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-12 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <p className="text-4xl mb-4">🎂🎉🎊🥳🎁</p>
          <p className="text-xl text-muted-foreground">
            Made with 💖 by Aviraj, just for Trisha
          </p>
          <p className="text-3xl mt-4 font-[var(--font-display)] text-primary">
            Happy Birthday, Trisha! 🌸
          </p>
        </motion.div>
      </footer>
    </div>
  );
};

export default Index;
