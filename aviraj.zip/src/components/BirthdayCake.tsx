import { motion } from "framer-motion";

const BirthdayCake = () => {
  return (
    <motion.div
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ type: "spring", stiffness: 200, delay: 0.5 }}
      className="text-center animate-cake-bounce"
    >
      <div className="text-8xl md:text-9xl">🎂</div>
      <motion.div
        className="flex justify-center gap-1 -mt-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        {[...Array(5)].map((_, i) => (
          <motion.span
            key={i}
            className="text-2xl"
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 1, delay: i * 0.2, repeat: Infinity }}
          >
            🕯️
          </motion.span>
        ))}
      </motion.div>
    </motion.div>
  );
};

export default BirthdayCake;
