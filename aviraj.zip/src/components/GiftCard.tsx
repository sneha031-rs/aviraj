import { motion } from "framer-motion";
import { useState } from "react";

interface GiftCardProps {
  emoji: string;
  title: string;
  message: string;
  color: string;
  delay: number;
}

const GiftCard = ({ emoji, title, message, color, delay }: GiftCardProps) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, rotateY: 90 }}
      whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
      transition={{ duration: 0.6, delay }}
      viewport={{ once: true }}
      onClick={() => setIsOpen(!isOpen)}
      className={`cursor-pointer rounded-2xl p-6 ${color} shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2`}
    >
      <motion.div
        animate={isOpen ? { rotateY: 360 } : {}}
        transition={{ duration: 0.5 }}
        className="text-5xl mb-4 text-center"
      >
        {emoji}
      </motion.div>
      <h3 className="text-xl font-bold text-center mb-2 font-[var(--font-display)]">{title}</h3>
      <motion.p
        initial={{ height: 0, opacity: 0 }}
        animate={isOpen ? { height: "auto", opacity: 1 } : { height: 0, opacity: 0 }}
        className="text-center text-sm text-foreground/70 overflow-hidden"
      >
        {message}
      </motion.p>
      {!isOpen && (
        <p className="text-center text-xs text-muted-foreground mt-2">Tap to open 💝</p>
      )}
    </motion.div>
  );
};

export default GiftCard;
